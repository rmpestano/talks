package com.calculator;

import java.util.Scanner;

import org.osgi.framework.BundleContext;

public class Calculator extends Thread {

	private volatile boolean active = true;
	private Scanner scanner;
	private BundleContext bundleContext;

	public Calculator(BundleContext bundleContext) {
		this.bundleContext = bundleContext;
	}

	@Override
	public void run() {
		scanner = new Scanner(System.in);
		while (active) {
				try {
					String input = scanner.nextLine();
					if (input.contains("+")) {
						 //modulo soma aqui
					} else if(input.contains("-")){
						 //modulo subtracao aqui
					}else if(input.contains("*")){
						 //modulo multiplicacao aqui
					}else if(input.contains("/")){
						 //modulo divisao aqui
					}

				} catch (Exception e) {
					System.out.println("Erro inexperado:" + e.getMessage());
				}
			}
		}

	public void stopThread() {
		this.active = false;
	}

}
